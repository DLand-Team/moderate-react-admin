// 按钮的key
const ACTION_KEY = {
    ADD: "ADD",
    EDIT: "EDIT",
    DELETE: "DELETE",
    IMPORT: "IMPORT"
    EXPORT: "EXPORT"
}

// 路由的key
const ROUTE_KEY = {
    index: "index",
    sys: "sys",
    role: "role",
    user: "user",
};