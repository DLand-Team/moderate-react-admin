const secret = 'moderate-vue-admin'; // 秘钥

module.exports ={
    secret
}