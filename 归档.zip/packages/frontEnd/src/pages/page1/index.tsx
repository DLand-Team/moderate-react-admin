import "react";
import styles from "./index.module.scss";

export default (props) => {
  return <div className={styles.content}>asdas</div>;
};
