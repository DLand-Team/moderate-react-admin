#  moderate-admin-react-antd5

## 技术选型
- React18
- Antd5
- mobx
- react-router 6.4.3
- vite
- ts

# 启动
```
第一步
yarn

第二部
yarn start
```

这样，一个全栈项目就跑起来了。

有问题请联系我，我的群号是：551406017
